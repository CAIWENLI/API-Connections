rm(list=ls())

library(RJDBC)
library(rJava)

# Download the driver from here and upload it to the working directory
# https://www.microsoft.com/en-us/download/details.aspx?id=11774

# Not working for me -Lisa

untar("sqljdbc_6.0.8112.100_enu.tar.gz")

drv <- JDBC("com.microsoft.sqlserver.jdbc.SQLServerDriver", "sqljdbc_6.0/enu/jre8/sqljdbc42.jar")

conn <- dbConnect(drv, 'jdbc:sqlserver://Bi.ztrac.com;databaseName=ZTracEnterpriseDataWarehouse', 'Nancy Castillo', 'Summer17')


# mySQL connection - Working 


# untar("~/R/Projects/R-DCM/Drivers/mysql-connector-java-5.1.45.tar.gz")

drv <- JDBC("com.mysql.jdbc.Driver", "~/R/Projects/R-DCM/Drivers/mysql-connector-java-5.1.45-bin.jar")

conn <- dbConnect(drv, 'jdbc:mysql://zen.ztrac.com:3306/zen_app', 'powerbi_user', 'elQKklrdJZHVTLVb')

conn <- dbConnect(drv, 'jdbc:mysql://zen.ztrac.com', 'powerbi_user', 'elQKklrdJZHVTLVb')


dbListTables(conn)
