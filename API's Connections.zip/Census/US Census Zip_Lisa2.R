rm(list=ls())

library(censusapi)
library(zipcode)

data("zipcode")

mycensuskey <- "df9e0036b1d36e28e6a40766e6f00e2ae4c6cee9"
myvintage <- 2017

# availablegeos <- listCensusMetadata(name = "acs/acs5", vintage = myvintage,  type = "g")
# availablevars <- listCensusMetadata(name = "acs/acs5", vintage = myvintage)

# B01003.  Total Population
# B09001.  Population Under 18 Years by Age
# B01002.  Median Age by Sex
# B25034.  Year Structure Built
# B25107.  Median Value by Year Structure Built
# B25009.  TENURE BY HOUSEHOLD SIZE

test <- getCensus(name = "acs/acs5", 
                       vintage=myvintage, 
                       key=mycensuskey, 
                       vars = c("NAME","B01003_001E","B01002_001E","B01002_002E","B01002_003E","B25034_001E", "B25034_002E","B25107_001E", "B25107_002E", "B25009_002E", "B25009_010E", "B09005_002E"), 
                       region = "zip code tabulation area:*")


colnames(test) <- c("zip", "zip_full", "total_pop", "median_age","median_age_male", "median_age_female" , "total_houses", "houses_built_after2014", "median_house_value", "median_house_value_after2014", "homeowner_pop", "renter_pop", "household_with_children_under18" )
test[test<0] <- 0

ll_store_master <- read.csv("~/R/Projects/R-DCM/Clients/Lumber Liquidators/Assets/Inputs/site_master.csv")

ll_store_master$postal.code <- as.character(ll_store_master$postal.code)
test$zip <- as.character(test$zip)

ll_demo <- ll_store_master %>% 
  inner_join(test, by = c("postal.code" = "zip"))

write.csv(ll_demo,"~/R/Projects/R-DCM/Clients/Lumber Liquidators/Assets/Outputs/ll_demo.csv")
