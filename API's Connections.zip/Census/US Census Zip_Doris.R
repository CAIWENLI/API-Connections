rm(list=ls())

library(censusapi)
library(zipcode)

data("zipcode")

mycensuskey <- "df9e0036b1d36e28e6a40766e6f00e2ae4c6cee9"
myvintage <- 2016

availablegeos <- listCensusMetadata(name = "acs/acs5", vintage = myvintage,  type = "g")
availablevars <- listCensusMetadata(name = "acs/acs5", vintage = myvintage)

data <- getCensus(name = "acs/acs5", 
                  vintage=myvintage, 
                  key=mycensuskey, 
                  vars = c("NAME", "B19013_001E", "B01002_001E", 
                           "B01003_001E","B01001_002E", "B01001_026E", "B02001_002E", "B02001_003E", "B02001_004E", "B02001_005E"), 
                  region = "zip code tabulation area:*")

colnames(data) <- c("Zip", "zip", "Median_Income", "Median_Age", 
                    "Total_Population", "Male_Population", "Female_Population", "White", "AfricanAmerican", "AmericanIndian_Alaska_Native", "Asian")


data <- mutate(data, Other = Total_Population - White - AfricanAmerican - AmericanIndian_Alaska_Native-Asian)


census <- merge(data, zipcode, by = "zip")

census <- filter(census, state == "IN")

census <- filter(census, zip == "47906" | zip == "47907")

write.csv(census, "census.csv", row.names = FALSE)

