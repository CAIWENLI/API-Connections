library(RPostgreSQL)
library(dplyr)

a <- 6417308 #Virgin Mobile Advertiser ID
b <- as.Date("2017-12-18")
i <- as.Date("2017-12-19")
c <- i+1

d <- 3635412 #DBM Virgin Mobile ID
e <- 4302931 #VMU - Legacy Order Confirmation Page - On Load
f <- 3553812 #VMU - IO ID


myRedShift <- src_postgres("dcmlogdata",
                           host = "dcm.cp1kfqsgbrzl.us-east-1.redshift.amazonaws.com", 
                           port = 5439,
                           user = "ruser",
                           password = rstudioapi::askForPassword("Please enter Amazon Redshift Password:"))


tables <- as.data.frame(src_tbls(myRedShift))

state <- tbl(myRedShift,"state")
site <- tbl(myRedShift, "site")
advertiser <- tbl(myRedShift,"advertiser")
conversion <- tbl(myRedShift, "activity")
impression <- tbl(myRedShift,"impression")
click <- tbl(myRedShift, "click")
placement <- tbl(myRedShift, "placement")
operatingsystem <- tbl(myRedShift, "operatingsystem")
floodlight <- tbl(myRedShift, "customfloodlightvariables")

df_placement <- as.data.frame(placement)
df_advertiser <- as.data.frame(advertiser)
df_system <- as.data.frame(operatingsystem)
df_site <- as.data.frame(site)
df_floodlight <- as.data.frame(floodlight)
df_activitycat <- as.data.frame(activitycats)

df_placement <- df_placement[!duplicated(df_placement$placementid),]

impression_total <- impression %>%
  filter(advertiserid== a, siteid == d, eventtime> b, eventtime < c, dbminsertionorderid == f) %>% 
  arrange(eventtime,dbmauctionid) %>% 
  ungroup()

impression_check <- impression_total %>%
  group_by(advertiserid, eventtime, dbminsertionorderid) %>%
  summarise(impression=n()) %>%
  collect()

