library(RPostgreSQL)
library(dplyr)

a <- 4913344 #Advertiser ID
b <- as.Date("2017-06-22")
i <- as.Date("2017-06-22")
c <- i+1

#d <- 3635412 #DBM Virgin Mobile ID
#e <- 4302931 #VMU - Legacy Order Confirmation Page - On Load


myRedShift <- src_postgres("dcmlogdata",
                           host = "dcm.cp1kfqsgbrzl.us-east-1.redshift.amazonaws.com", 
                           port = 5439,
                           user = "ruser",
                           password = rstudioapi::askForPassword("Please enter Amazon Redshift Password:"))

tables <- as.data.frame(src_tbls(myRedShift))


conversion <- tbl(myRedShift, "activity")
impression <- tbl(myRedShift, "impression")
click <- tbl(myRedShift, "click")
advertiser <- tbl(myRedShift,"advertiser")

df_advertiser <- as.data.frame(advertiser)

test <- as.data.frame(tbl_vars(conversion))

conversion_total <- conversion %>%
  filter(eventtime> b, eventtime < c)%>% arrange(eventtime,dbmauctionid) %>% group_by(eventtime) %>% ungroup()

number_conversion <- conversion_total %>%
  mutate(year=date_part('year', eventtime), month=date_part('month', eventtime), day=date_part('day', eventtime))%>%
  group_by(activityid, advertiserid, year, month, day) %>%
  summarise(conversion=sum(totalconversions)) %>%
  collect()

number_conversion <- merge(number_conversion, df_advertiser, by = "advertiserid")

number_conversion$advertisergroup <- NULL
number_conversion$advetisergroupid <- NULL

write.csv(number_conversion, "/home/dorissun/R/Projects/R-DCM/Generic/Assets/Output/number_conversion.csv", row.names=F)
