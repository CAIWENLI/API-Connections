library(rstudioapi)
library(RPostgreSQL)
library(dplyr)
library(tidyr)

myRedshift <- src_postgres('dcmlogdata',
                           host = "dcm.cp1kfqsgbrzl.us-east-1.redshift.amazonaws.com",
                           port = 5439,
                           user = "ruser", 
                           password = rstudioapi::askForPassword("Please enter Amazon Redshift Password:"))

impression <- tbl(myRedshift,"impression")
click <- tbl(myRedshift,"click")
activity <- tbl(myRedshift,"activity")

head(impression)

head(activity)