# Clear all the variables
rm(list=ls())

library(RPostgreSQL)
library(dplyr)
library(dbplyr)
library(data.table)
library(lubridate)
library(reshape2)

# Create a connection to Redshift database from the dplyr package
myRedshift <- src_postgres('dcmlogdata',
                           host = "dcm.cp1kfqsgbrzl.us-east-1.redshift.amazonaws.com",
                           port = 5439,
                           user = "ruser", 
                           password = "RUser2017")
# Create a table reference using the function tbl() (remote source in redshift database)
src_tbls(myRedshift)

impression <- tbl(myRedshift,"impression")
click <- tbl(myRedshift,"click")
activity <- tbl(myRedshift,"activity")
site <- tbl(myRedshift,"site")
paidsearch <- tbl(myRedshift,"paidsearch")
head(paidsearch)

# Filter stores that are open during the whole period (2016/2017)
open_store_query <- tranitemSummary %>%
  filter(trandate >= start.date,trandate < end.date) %>% 
  select(trandate,storeid) %>%
  left_join(fiscalCalendar, by = c("trandate" = "fiscalday")) %>% # Filter out the stores based on fiscalday
  select(weekstart,storeid) %>% 
  distinct() %>% 
  group_by(storeid) %>% 
  summarise(nb_weeks=n()) %>% 
  ungroup() %>% 
  filter(nb_weeks==105) %>% 
  select(storeid)
