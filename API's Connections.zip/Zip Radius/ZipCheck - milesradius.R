
library(geosphere)
library(dplyr)
library(zipcode)
library(RCurl)
library(RJSONIO)
library(plyr)

b <- 5 # miles in radius
u <- "mariannerochet" #Ruser

data(zipcode.civicspace)

zipcode.civicspace$timezone <- NULL
zipcode.civicspace$dst <- NULL

ziplist <- array()


#target <- read.csv(paste0("/home/",u,"/R/Projects/R-DCM/Generic/Assets/Inputs/ziplist.csv"))

library(boxr)
#devtools::install_github("brendan-r/boxr")

client_id <-"okq2flju24fgrtmyoch72vwycojmnirx"
client_secret <- "KsmC8rC6FGqZWVqvfm0E8OAYBGRfuFeB"

box_auth(client_id = client_id,  client_secret = client_secret,cache = "~/R/Projects/R-DCM/Generic/Assets/Inputs/.boxr-oauth", write.Renv = TRUE)

target <- box_read(299414440652)

target <- target[complete.cases(target),]


for (i in 1: length(target$Location))
{
#distm(c(-80.1887562, 26.2090245), c(-80.1871195, 26.1653605), fun = distGeo)


a <- as.character(target[i,2])

ab <- target[ i ,c("longitude","latitude")]

ab2 <- zipcode.civicspace[,c("longitude", "latitude")]

test <- as.data.frame(distm(ab, ab2))
               
test1 <- as.data.frame(t(test))

test2 <- cbind(zipcode.civicspace,test1)

colnames(test2) <- c("zip", "city", "state", "latitude", "longitude", "meter")

test2 <- mutate(test2, kilometer = meter/1000, miles = kilometer * 0.621371)

zip1 <- filter(test2, miles <= b)

zip1 <- mutate(zip1, Location = a)

ziplist <- rbind(zip1, ziplist)

ziplist <- filter(ziplist, Location !="")

}


ziplist2 <- merge(target, ziplist, by="Location")

write.csv(ziplist2, paste0("~/R/Projects/R-DCM/Generic/Assets/Outputs/ziplist.csv"),  row.names=F)
