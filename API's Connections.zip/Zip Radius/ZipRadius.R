library(devtools)
library(ZipRadius)
library(ggplot2)
library(geosphere)
library(magrittr) # need to run every time you start R and want to use %>%
library(dplyr)    # alternative, this also loads %>%

#get a zip radius!

test <- zipRadius("33484", 1.5)
test

