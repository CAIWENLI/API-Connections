
library(devtools)
library(curl)
library(ggplot2)
library(rga)

require("dplyr")
require("lubridate")
require("reshape")


config.folder.location <- "\\home\\dorissun\\R\\Projects\\R-DCM\\Generic\\Assets\\Inputs\\config"

working.directory <- config.folder.location

#load("/home/dorissun/R/Projects/R-DCM/Generic/Assets/Inputs/config/ga.rga")

#rga.open(instance="ga", where="/home/dorissun/R/Projects/R-DCM/Generic/Assets/Inputs/config/ga.rga")

rga.open(instance="ga")

save(ga, file="/home/dorissun/R/Projects/R-DCM/Generic/Assets/Inputs/config/ga.rga")

currentDate      <- Sys.Date()
end   <- rollback(currentDate)
init <- rollback(end, roll_to_first  = T)

rga.open(instance = "ga")

rga.open(instance="ga", where="~/ga.rga")

##Setting up IDs

id <- "122676987"


##Import Data from GA

#gaid::ScwbKGw5QAGH-tbMXeo8dA MOBILE AND TABLET NEW

new <- ga$getData(id,start.date = init, end.date = end,
                  metrics="ga:sessions, ga:users",
                  dimensions = "ga:year, ga:month, ga:deviceCategory",
                  batch= TRUE, walk=FALSE)
